# FitPulse — Mobile App UI Prototype (Week 2 Submission)

[![Framework](https://img.shields.io/badge/Framework-Flutter_3.x-blue)]()
[![Language](https://img.shields.io/badge/Language-Dart_3.x-0175C2)]()
[![UI_Design](https://img.shields.io/badge/Design-Material_3-purple)]()

FitPulse is a modern, modular Flutter mobile application prototype built as part of the Week 2 internship task. This project translates the Week 1 wireframes into a fully functional, cross-platform user interface codebase.

---

## 🏗️ Codebase Architecture

The application utilizes a **Feature-First Architecture** to isolate business domains, improve code readability, and ensure clean separation of concerns:

```text
fitpulse_app/
├── lib/
│   ├── main.dart                          # Application entry point & theme initialization
│   ├── core/
│   │   ├── constants/
│   │   │   └── app_colors.dart            # Centralized UI color tokens
│   │   └── theme/
│   │       └── app_theme.dart             # App-wide Material 3 theme configuration
│   ├── navigation/
│   │   └── main_navigation_shell.dart     # Persistent BottomNavigationBar via IndexedStack
│   └── features/
│       ├── dashboard/
│       │   └── dashboard_screen.dart      # Progress rings, habit cards, quick start CTA
│       ├── workout/
│       │   └── workout_tracker_screen.dart# Active timers & interactive set/rep loggers
│       ├── habits/
│       │   └── habit_log_screen.dart      # Calendar strip & toggleable checklist
│       ├── analytics/
│       │   └── analytics_screen.dart      # Volume bar charts & metrics summary grid
│       └── profile/
│           └── profile_screen.dart        # User goals, preferences & settings list
├── screenshots/                           # High-resolution running app screen captures
├── pubspec.yaml
└── README.md

🎨 Design Decisions & UI Implementation

State Preservation (IndexedStack): The primary navigation shell uses IndexedStack to keep all 5 primary screens active in memory, preventing unnecessary re-renders when switching tabs.

Ergonomic Call-To-Actions: Interaction triggers (e.g., START WORKOUT, LOG SET) are rendered as full-width buttons in the lower third of the display for comfortable thumb accessibility.

Material 3 Design Tokens: Standardized on clean off-white background surfaces (#F8FAFC), crisp border outlines (#E2E8F0), deep blue primary headers (#1E3A8A), and dynamic accent indicators (#3B82F6).